#include <iostream>
#include <thread>

int main(int argc, char ** argv)
{
    while(1);
}
