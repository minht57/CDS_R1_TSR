#include <stdio.h>

//#define DBGI(level,instruction) if(DEBUG_LEVEL>=level) instruction
#define NMAX 1000000
  
void solveAssignmentProblemintRect(int **Array, int **Result, int m, int n);

void solveMinWeightEdgeCover(int **Array, int **Result, int size1, int size2);