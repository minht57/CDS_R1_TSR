
#define PRINT_FRAME_RATE

#define SHOW_OUTPUT_VIDEO

#define OUTPUT_DIR "C:\\Data\\Vehicle\\traffic"
//#define OUTPUT_DIR "C:\\Data\\Vehicle\\traffic-violations"
//#define OUTPUT_DIR "."

#define CAM_IP_ADRESS  "14.177.198.197"//"14.177.195.65"

#define MASK_FILENAME "mask3.jpg"

#define ROT_ANGLE 0.0

#define INPUT_SCALE 1.4

#include "def_cam.h"
#include "def_vid.h"
